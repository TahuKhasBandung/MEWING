from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:\.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
	inline = [
[Button.inline("🔥PANEL CREATE ACCOUNT🔥","menu")],
[Button.url("🙈ORANG GANTENG","https://t.me/riristore"),
Button.url("☎️ORDER SCRIPT","https://t.me/riristore")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("📵 Pinjam Dulu 100📵", alert=True)
		except:
			await event.reply("📵 Pinjam Dulu 100📵")
	elif val == "true":
		try:
			sh = f' cat /etc/ssh/.ssh.db 2>/dev/null | grep "###" | wc -l'
			ssh = subprocess.check_output(sh, shell=True).decode("ascii")
		except:
			ssh = "0"
		try:
			vm = f' cat /etc/vmess/.vmess.db 2>/dev/null | grep "###" | wc -l'
			vms = subprocess.check_output(vm, shell=True).decode("ascii")
		except:
			vms = "0"
		try:
			vl = f' cat /etc/vless/.vless.db 2>/dev/null | grep "###" | wc -l'
			vls = subprocess.check_output(vl, shell=True).decode("ascii")
		except:
			vls = "0"
		try:
			tr = f' cat /etc/trojan/.trojan.db 2>/dev/null | grep "###" | wc -l'
			trj = subprocess.check_output(tr, shell=True).decode("ascii")
		except:
			trj = "0"
		try:
			sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
			namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
		except:
			namaos = "Unknown"
		try:
			ipvps = f" curl -s ipv4.icanhazip.com"
			ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
		except:
			ipsaya = "Unknown"
		try:
			citsy = f" cat /etc/xray/city"
			city = subprocess.check_output(citsy, shell=True).decode("ascii")
		except:
			city = "Unknown"

		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**☘️🔰 PREMIUM PANEL MENU 🔰☘️**
━━━━━━━━━━━━━━━━━━━━━━━ 
🔰 **» OS     :** `{namaos.strip().replace('"','')}`
🔰 **» CITY :** `{city.strip()}`
🔰 **» DOMAIN :** `{DOMAIN}`
🔰 **» IP VPS :** `{ipsaya.strip()}`
━━━━━━━━━━━━━━━━━━━━━━━
"""
		try:
			await event.edit(msg,buttons=inline)
		except:
			await event.reply(msg,buttons=inline)
